package com.company;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;

public class CallLog {
    private Instant date;
    private long phoneNumber;

    public CallLog(Instant date, long phoneNumber) {
        this.date = date;
        this.phoneNumber = phoneNumber;
    }

    public Instant getDate() {
        return date;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public static Collection<CallLog> findDate(Collection<CallLog> dateCollection, String inputDate) {
        Collection<CallLog> callLogs = new ArrayList<>();
        for (CallLog log : dateCollection) {
            if (log.getDate().toString().equals(inputDate)) {
                callLogs.add(log);
            }
        }
        return callLogs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CallLog log = (CallLog) o;
        return phoneNumber == log.phoneNumber &&
                date.equals(log.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, phoneNumber);
    }
}
