package com.company;

import java.util.Queue;
import java.util.concurrent.ThreadLocalRandom;

public class ProducerTask implements Runnable {
    private final Queue<Item> itemQueue;

    public ProducerTask(Queue<Item> itemQueue) {
        this.itemQueue = itemQueue;
    }

    @Override
    public void run() {

    }

    private Item produceItem() throws InterruptedException {
        while (Thread.currentThread().isInterrupted()) {
            produceItem();
        }
        int sleepInterval = ThreadLocalRandom.current().nextInt(50, 200);
        Thread.sleep(sleepInterval);
        return new Item(sleepInterval);
    }
}
