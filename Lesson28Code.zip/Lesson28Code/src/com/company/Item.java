package com.company;

public class Item {
    public final int value;

    public Item(int value) {
        this.value = value;
    }
}
