package com.company;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {

    public static void main(String[] args) {
	// write your code here
        new Main().run();
    }

    public void run() {
        Queue<Item> sharedQueue = new LinkedList<>();

        ExecutorService executor = Executors.newCachedThreadPool();
        executor.execute(new ConsumerTask(sharedQueue));
        executor.execute(new ProducerTask(sharedQueue));
    }
}
