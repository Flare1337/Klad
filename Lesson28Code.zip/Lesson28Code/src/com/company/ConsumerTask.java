package com.company;

import java.util.Queue;

public class ConsumerTask implements Runnable {
    private final Queue<Item> itemQueue;

    public ConsumerTask(Queue<Item> itemQueue) {
        this.itemQueue = itemQueue;
    }

    @Override
    public void run() {
        // TO DO
    }
}
