public class Student {
    private int age;
    private String name;
    private int averageMark;
    private int ID;

    public Student(String name, int age, int averageMark, int ID) {
        this.name = name;
        this.age = age;
        this.averageMark = averageMark;
        this.ID = ID;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAverageMark() {
        return averageMark;
    }

    public void setAverageMark(int averageMark) {
        this.averageMark = averageMark;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}
