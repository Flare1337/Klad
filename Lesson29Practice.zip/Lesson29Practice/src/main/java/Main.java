import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        try {
      //      new Main().connectAndDeleteTable();
            new Main().invokeConsoleMenu();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void connectAndCreateTable() throws SQLException {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:sample.db")) {
            Statement statement = connection.createStatement();
            statement.executeUpdate("CREATE TABLE person (id INTEGER, name VARCHAR(100))");
        }
    }

    public void connectAndDeleteTable() throws SQLException {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:sample.db")) {
            Statement statement = connection.createStatement();
            statement.executeUpdate("DROP TABLE person (id INTEGER, name VARCHAR(100))");
        }
    }

    public void invokeConsoleMenu() throws SQLException {
        int input = 0;
        while (input != 9) {
            System.out.println("Choose a service from the menu: \n" +
                                "1 - create a table with students \n" +
                                "2 - delete a table \n" +
                                "3 - add a student \n" +
                                "4 - display sorted table \n" +
                                "5 - show a kitten photo \n" +
                                "6 - find student(s) \n" +
                                "7 - create a text file \n" +
                                "8 - download a film \n" +
                                "9 - shutdown the program");
            Scanner scanner = new Scanner(System.in);
            switch (input = scanner.nextInt()) {
                case 1:
                    connectAndCreateTable();
                    System.out.println("Table is created");
                break;
                case 2:
                    connectAndDeleteTable();
                    System.out.println("Table with students is deleted");
                break;
                case 3: System.out.println("The student is added");
                break;
                case 4: System.out.println("The sorted table is displayed!");
                break;
                case 5: System.out.println("The kitten photo is shown");
                break;
                case 6: System.out.println("The student(s) found");
                break;
                case 7: System.out.println("A text file is created");
                break;
                case 8: System.out.println("The downloading of a film is started");
                break;
                case 9: System.out.println("Ok, i'm done...");
                break;
                default:
                    System.out.println("What are you try'na to say?");
            }
        }
    }
}
